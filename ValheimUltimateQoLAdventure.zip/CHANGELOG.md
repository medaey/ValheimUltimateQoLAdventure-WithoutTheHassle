# Changelog

24.12.242315
- Fix README file

24.12.242301
- Add mod Azumatt-DeathPinRemoval
- Add mod Azumatt-Build_Camera_Custom_Hammers_Edition
- Add config to ItemDrawers
- Add config to valheim_plus
- Add config to QuickTapDodge
- Add config to Azumatt.AzuSkillTweaks
- Add config to xstorage

24.12.242000
- Update README

24.12.241930
- Added screenshots to README

24.12.241847
- Updated mod name in Thunderstore