# Changelog

24.12.262154
- Added mod level detailed
- Added mod SaveFrequency
- Added mod SmoothSave

24.12.260806
- fix equipement wheel hotkey

24.12.260800
- fix equipement wheel hotkey

24.12.260359
- Valhiem plus change config.

24.12.260200
- QuickTapDodge 0.18 to 0.25

24.12.260144
- Fix PlantEasily config
- Fix PlantEverything config

24.12.240116
- PlantEasily HarvestRadius increas 3 to 15

24.12.240046
- Added config for advize.PlantEasily

24.12.240033
- Update README file

24.12.242356
- Added config for EquipWheel
- Added config for AzuExtendedPlayerInventory
- Added config for LongerDays 60%
- Changed DrawerPickupRange from 100 to 200
- Removed mod Azumatt-Build_Camera_Custom_Hammers_Edition

24.12.242320
- Update README file

24.12.242315
- Fixed README file

24.12.242301
- Added mod Azumatt-DeathPinRemoval
- Added mod Azumatt-Build_Camera_Custom_Hammers_Edition
- Added config for ItemDrawers
- Added config for valheim_plus
- Added config for QuickTapDodge
- Added config for Azumatt.AzuSkillTweaks
- Added config for xstorage

24.12.241930
- Added screenshots to README

24.12.241847
- Updated mod name in Thunderstore