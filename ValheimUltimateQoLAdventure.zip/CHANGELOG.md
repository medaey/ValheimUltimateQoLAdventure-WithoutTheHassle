# Changelog

25.1.42335
- update DiscoveryPins 0.3.4 -> 0.3.6

24.12.300400
- Fix PlantEverything config

24.12.281000
- add mod BetterRiding

24.12.280300
- Configure mod QuickTapDodge 0.25 to 0.18
- add mod BetterSplitDialog
- add mod PerfectPlacement

24.12.280200
- Configure mod TeleportEverything Transport Only named entity

24.12.280100
- Configure mod valheim_plus increase Windmill maximumBerley  10 to 100
- Configure mod valheim_plus increase Windmill productionSpeed

24.12.272300
- Hip Lanter uses Resin for refueling
- Configure mod SeedTotem to not check the biome
- Configure mod PlantEverything set RespawnTime to 480
- Remove mod SeedBed

24.12.272200
- update mod Warfare
- update mod HookGenPatch

24.12.270900
- remove mod ElderscrollianThemedSoundtrack

24.12.270800
- remove mod MinecraftStuff
- remove mod PlanBuild
- update mod DiscoveryPins

24.12.270700
- remove mod OdinTrainingPlace
- remove mod CraftingStationsLevelBasedBuildRange
- remove mod Plateautem
- add mod ElderscrollianThemedSoundtrack
- add mod SearchableBuildMenu
- add mod SeedBed

24.12.270605
- dicrease Fiddlehead farming
- dicrease Smokepuff farming

24.12.270458
- add mod HipLantern

24.12.270454
- add mod Plateautem
- add mod SeedTotem

24.12.270425
- add mod Colored_Food_UI
- dicrease Return planting gift everything

24.12.270411
- add mod PingTweaks

24.12.270345
- add mod PlanBuild
- add mod OdinTrainingPlace
- add mod CustomAudio-LocationMusic
- add mod FishTrap
- add mod PetPantry

24.12.270054
- Added config for Veinmine
- Update README

24.12.262248
- Increase planting grid row 5 to 10

24.12.262223
- Increase HarvestRadius 3 to 20

24.12.262214
- Added Mod MorePins
- fix Equip Wheel Hotkey

24.12.262203
- Remove not work mod "SmoothSave"

24.12.262154
- Added mod DetailedLevels
- Added mod SaveFrequency
- Added mod SmoothSave

24.12.260806
- fix equipement wheel hotkey

24.12.260800
- fix equipement wheel hotkey

24.12.260359
- Valhiem plus change config.

24.12.260200
- QuickTapDodge 0.18 to 0.25

24.12.260144
- Fix PlantEasily config
- Fix PlantEverything config

24.12.240116
- PlantEasily HarvestRadius increas 3 to 15

24.12.240046
- Added config for advize.PlantEasily

24.12.240033
- Update README file

24.12.242356
- Added config for EquipWheel
- Added config for AzuExtendedPlayerInventory
- Added config for LongerDays 60%
- Changed DrawerPickupRange from 100 to 200
- Removed mod Azumatt-Build_Camera_Custom_Hammers_Edition

24.12.242320
- Update README file

24.12.242315
- Fixed README file

24.12.242301
- Added mod Azumatt-DeathPinRemoval
- Added mod Azumatt-Build_Camera_Custom_Hammers_Edition
- Added config for ItemDrawers
- Added config for valheim_plus
- Added config for QuickTapDodge
- Added config for Azumatt.AzuSkillTweaks
- Added config for xstorage

24.12.241930
- Added screenshots to README

24.12.241847
- Updated mod name in Thunderstore