# Changelog

<details>
  <summary>24.12.241930</summary>
  - Added screenshots to README.md
</details>

<details>
  <summary>24.12.241847</summary>
  - Updated mod name in Thunderstore
</details>
