# Changelog

24.12.242235
- Add mod Azumatt-DeathPinRemoval
- Add config from ItemDrawers
- Add config for valheim_plus
- Add config for QuickTapDodge

24.12.242000
- Update README.md

24.12.241930
- Added screenshots to README.md

24.12.241847
- Updated mod name in Thunderstore