<details>
 <summary>24.12.241847</summary>
 - Update mod name in Thunderstore.
</details>